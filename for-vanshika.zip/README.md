# For Vanshika — Cute Apology Page

A tiny static site to say sorry and make Vanshika smile. 💌

## How to use
1. Create a new GitHub repository (public).
2. Upload these files.
3. Enable GitHub Pages in Settings → Pages → Branch: `main`, Folder: `/ (root)`.
4. Share the link with Vanshika. ❤️
